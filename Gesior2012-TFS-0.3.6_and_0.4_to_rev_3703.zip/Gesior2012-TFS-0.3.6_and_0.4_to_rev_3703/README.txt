##### CREDITS #####
Version 1.0.3 for TFS 0.3.6 and TFS 0.4 up to revision 3702
Acc. script:
*Gesior - e-mail: phoowned@wp.pl
Layouts:
*CipSoft Gmbh - www.tibia.com
Monsters images:
*Unknown author